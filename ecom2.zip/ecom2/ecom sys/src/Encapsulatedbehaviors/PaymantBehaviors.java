package Encapsulatedbehaviors;

public interface PaymantBehaviors {
     public int currencyValue();
     public boolean checkcountry(String s);
}

