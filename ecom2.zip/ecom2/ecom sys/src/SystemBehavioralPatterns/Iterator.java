package SystemBehavioralPatterns;


public interface Iterator {
     public Object next();
     public boolean hasNext();
     public int setcounter(String s);
}
